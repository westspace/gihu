//
//  CBUtils.swift
//  ClimateAction
//
//  Copyright © CODExBridge. All rights reserved.
//

import UIKit
import CFAlertViewController

extension UIViewController {
    
    func showNotification(title: String, message: String?, completion: @escaping ((Bool) -> Void) = { _ in }) {
        if message == nil || message == "" {
            completion(false)
            return
        }

        let alertController = CFAlertViewController(title: title, message: message, textAlignment: .center, preferredStyle: .notification) { (dismissReason) in
            completion(true)
        }
        present(alertController, animated: true, completion: nil)
    }

    func showAlert(title: String, message: String?, buttonBgColor: UIColor, buttonTextColor: UIColor, completion: @escaping (Bool) -> () = { _ in }) {
        if message == nil || message == "" {
            completion (false)
            return
        }
        
        let defaultAction = CFAlertAction(title: "확인",
                                          style: .Default,
                                          alignment: .right,
                                          backgroundColor: buttonBgColor,
                                          textColor: buttonTextColor,
                                          handler: { (action) in
                                            completion(true)
        })
        
        let alertController = CFAlertViewController(title: title, message: message, textAlignment: .left, preferredStyle: .alert, didDismissAlertHandler: { (dismissReason) in
            completion(false)
        })
        
        alertController.addAction(defaultAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    func showAlert(title: String, message: String?, completion: @escaping (Bool) -> () = { _ in }) {
        
        showAlert(title: title, message: message, buttonBgColor: UIColor(red: 0.07, green: 0.4, blue: 1.0, alpha: 1.0), buttonTextColor: UIColor(white: 1, alpha: 1)) { (result) in
            completion(result)
        }
    }
    
    func showConfirm(title: String, message: String?, buttonBgColor: UIColor, buttonTextColor: UIColor, completion: @escaping (Bool) -> () = { _ in }) {
        if message == nil || message == "" {
            completion (false)
            return
        }
        
        let defaultAction = CFAlertAction(title: "확인",
                                          style: .Default,
                                          alignment: .justified,
                                          backgroundColor: buttonBgColor,
                                          textColor: buttonTextColor,
                                          handler: { (action) in
                                            completion(true)
        })
        
        let cancelAction = CFAlertAction(title: "취소",
                                         style: .Cancel,
                                         alignment: .justified,
                                         backgroundColor: nil,
                                         textColor: nil,
                                         handler: { (action) in
                                           completion(false)
        })

        let alertController = CFAlertViewController(title: title, message: message, textAlignment: .left, preferredStyle: .actionSheet, didDismissAlertHandler: nil)
        
        alertController.addAction(defaultAction)
        alertController.addAction(cancelAction)

        present(alertController, animated: true, completion: nil)
    }

    func showConfirm(title: String, message: String?, completion: @escaping (Bool) -> () = { _ in }) {
        showConfirm(title: title, message: message, buttonBgColor: UIColor(red: 0.07, green: 0.4, blue: 1.0, alpha: 1.0), buttonTextColor: UIColor(white: 1, alpha: 1)) { (result) in
            completion(result)
        }
    }
}
