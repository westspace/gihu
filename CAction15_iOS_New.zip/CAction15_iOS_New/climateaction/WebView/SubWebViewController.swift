//
//  SubWebViewController.swift
//  ClimateAction
//
//  Copyright © CODExBridge. All rights reserved.
//

import UIKit
import WebKit
import SafariServices
import Alamofire

class SubWebViewController: BaseWebViewController {
    public var loadURL: URL!
    public var introMode = false
    public var loginMode = false

    override func loadView() {
        super.loadView()
        
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        
        if loginMode {
            return nil
        }
        else {
            return super.webView(webView, createWebViewWith: configuration, for: navigationAction, windowFeatures: windowFeatures)
        }
    }
    
    // MARK: 뷰 라이프사이클
    override func viewDidLoad() {
        super.viewDidLoad()
        HTTPCookieStorage.shared.cookieAcceptPolicy = HTTPCookie.AcceptPolicy.always
        
        self.navigationController?.setNavigationBarHidden(!introMode, animated: true)
        //checkversion()
    }
    
    override func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "Mobile" && introMode {
            webViewUtil.setData("Y", key: "Intro")
            dismiss(animated: true)
            return
        }
        
        super.userContentController(userContentController, didReceive: message)
    }
    
    override func webViewDidClose(_ webView: WKWebView) {
        if loginMode {
            dismiss(animated: true)
            return
        }

        super.webViewDidClose(webView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        if self.loadedURL != nil {
            return
        }

        loadWebView(url: loadURL)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
