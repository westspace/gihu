//
//  AuthWebViewController.swift
//  climateaction
//
//  Created by 신현섭 on 1/25/24.
//  Copyright © 2024 CODExBridge. All rights reserved.
//

import UIKit
import WebKit


class AuthWebViewController: UIViewController, UIScrollViewDelegate, UINavigationControllerDelegate, WKNavigationDelegate, WKUIDelegate {
    @IBOutlet weak var webViewContainer: UIView!

    var webView: WKWebView
    
    init?(webView: WKWebView, coder: NSCoder) {
        self.webView = webView

        super.init(coder: coder)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {        
        self.navigationController?.setNavigationBarHidden(false, animated: true)

        self.webView.frame = self.webViewContainer.bounds
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.delegate = self
        webView.scrollView.bounces = true
        webView.scrollView.contentSize = webView.bounds.size
        
        webView.navigationDelegate = self
        webView.uiDelegate = self
        
        webView.allowsBackForwardNavigationGestures = true
        self.webViewContainer.addSubview(self.webView)
        super.viewDidLoad()
    }
    
    func webViewDidClose(_ webView: WKWebView) {
        self.navigationController?.popViewController(animated: true)
    }
}
