//
//  WebViewUtil.swift
//  ClimateAction
//
//  Copyright © CODExBridge. All rights reserved.
//

import UIKit
import WebKit

enum UXUrls {
    case main
    case intro
    case back
    case forward
    case walk
    case trysave
    case lastwalk
}

class WebViewUtil: NSObject {

    var viewController: UIViewController?
    var webView: WKWebView?
    var baseURL: String = "https://c-action.kr"
//    var baseURL: String = "http://122.199.152.150:8034"

    func getURL(function: UXUrls) -> URL {
        var urlString : String
        
        switch function {
        case .main:
            urlString = String(format: "%@/index.html", baseURL)
        case .intro:
            urlString = String(format: "%@/intro.html", baseURL)
        case .back:
            urlString = "javascript:history.back();";
        case .forward:
            urlString = "javascript:history.forward();";
        case .walk:
            urlString = String(format: "%@/api/walk/save.proc", baseURL)
        case .trysave:
            urlString = String(format: "%@/api/walk/update_try.proc", baseURL)
        case .lastwalk:
            urlString = String(format: "%@/api/walk/get_last_walk.ajax", baseURL)
        }
        
        return URL(string: urlString)!
    }
    
    func setData(_ value: Any, key: String) {
        let ud = UserDefaults.standard
        let archivedPool = try? NSKeyedArchiver.archivedData(withRootObject: value, requiringSecureCoding: true)
        ud.set(archivedPool, forKey: key)
    }
    
    func getData<T>(key: String) -> T? {
        let ud = UserDefaults.standard
        if let val = ud.value(forKey: key) as? Data,
           let obj = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(val) as? T {
            return obj
        }
        return nil
    }
    
    // MARK: - WebView Bridge Functions
    // URL 형식: myscheme://interfacename//interfacevalue
    // 또는: myscheme://interfacename
    func extractInterfaceInfo(from urlString: String) -> (name: String, value: String?)? {
        if let url = URL(string: urlString), let scheme = url.scheme {
            let remainingString = urlString.replacingOccurrences(of: "\(scheme)://", with: "")
            
            // 스키마와 나머지 부분을 "://"로 분리합니다.
            let components = remainingString.components(separatedBy: "//")
            
            if components.count >= 1 {
                // 인터페이스 이름은 항상 첫 번째 컴포넌트입니다.
                let interfaceName = components[0]
                
                // 나머지 부분을 인터페이스 값으로 사용합니다.
                var interfaceValue: String?
                
                if components.count > 1 {
                    interfaceValue = components[1]
                }
                
                return (interfaceName, interfaceValue)
            }
        }
        return nil // 유효하지 않은 URL 형식 또는 인터페이스 정보가 없는 경우 nil 반환
    }
}

class CompletionHandlerWrapper<Element> {
  private var completionHandler: ((Element) -> Void)?
  private let defaultValue: Element

  init(completionHandler: @escaping ((Element) -> Void), defaultValue: Element) {
    self.completionHandler = completionHandler
    self.defaultValue = defaultValue
  }

  func respondHandler(_ value: Element) {
    completionHandler?(value)
    completionHandler = nil
  }

  deinit {
    respondHandler(defaultValue)
  }
}

class DecisionHandlerWrapper<Element> {
  private var decisionHandler: ((Element) -> Void)?
  private let defaultValue: Element

  init(decisionHandler: @escaping ((Element) -> Void), defaultValue: Element) {
    self.decisionHandler = decisionHandler
    self.defaultValue = defaultValue
  }

  func respondHandler(_ value: Element) {
      decisionHandler?(value)
      decisionHandler = nil
  }

  deinit {
    respondHandler(defaultValue)
  }
}
