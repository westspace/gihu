//
//  MainWebViewController.swift
//  ClimateAction
//
//  Copyright © CODExBridge. All rights reserved.
//

import UIKit
import WebKit
import SafariServices
import Alamofire

class MainWebViewController: BaseWebViewController {
    override func loadView() {
        // 푸쉬 웹 URL 열기
        NotificationCenter.default.addObserver(forName: Notification.Name("openPushURL"), object: nil, queue: nil) { notification in
            
            // viewdidappear에서 한번 더 로드되는 것을 방지함.
            let link = notification.userInfo?["link"] as? String ?? ""
//            self.loadedURL = URL(string: link)
            if let url = URL(string: link) {
                // URL이 정상적으로 생성된 경우
                self.loadedURL = url
                // 추가로 수행해야 할 작업 수행
            } else {
                // URL 생성이 실패한 경우
                print("Invalid URL: \(link)")
                
                // 기본 URL 설정
                let defaultURLString = "https://c-action.kr"
                if let defaultURL = URL(string: defaultURLString) {
                    self.loadedURL = defaultURL
                    // 추가로 수행해야 할 작업 수행
                } else {
                    // 기본 URL도 생성이 실패한 경우에 대한 예외 처리 또는 기타 작업 수행
                    print("Invalid default URL: \(defaultURLString)")
                }
            }


            self.loadWebView(url: self.loadedURL)
        }
        
        super.loadView()
    }
    
    @IBAction func navigateFoward(_ sender: Any) {
        if let webView = self.webViewStack.last {
            if webView.canGoForward {
                webView.goForward()
                print("webview go forward!")
            }
        }
    }
    @IBAction func navigateBack(_ sender: Any) {
        if let webView = self.webViewStack.last {
            if webView.canGoBack {
                webView.goBack()
                print("webview go back!")
            }
        }
    }
    @IBAction func navigateHome(_ sender: Any) {
        if self.webViewStack.count == 1 {
            let loadURL = webViewUtil.getURL(function: .main)
            loadWebView(url: loadURL)
        }
    }
    
    // MARK: 뷰 라이프사이클
    override func viewDidLoad() {
        super.viewDidLoad()
        
        HTTPCookieStorage.shared.cookieAcceptPolicy = HTTPCookie.AcceptPolicy.always
        
        // Intro가 필요한 경우 Intro 먼저 띄우기
        
        let showIntro: String? = webViewUtil.getData(key: "Intro")
        
        if showIntro == nil || showIntro != "Y" {
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let subViewController = storyBoard.instantiateViewController(withIdentifier: "subWebViewController") as! SubWebViewController
            subViewController.loadURL = webViewUtil.getURL(function: .intro)
            subViewController.introMode = true
            subViewController.navigationController?.isNavigationBarHidden = true

            DispatchQueue.main.async {
                self.present(subViewController, animated:true, completion:nil)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if self.loadedURL != nil {
            return
        }

        let loadURL = webViewUtil.getURL(function: .main)
        loadWebView(url: loadURL)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        super.userContentController(userContentController, didReceive: message)
        
        if message.name == "Mobile", let result = parseMessageBodyToDict(messageBody: message.body) {
            if let push_yn = result["push_yn"] as? String {
                webViewUtil.setData(push_yn, key: "push_YN")
                
                if push_yn == "Y" {
                    // 푸쉬 알림 권한 허용 요청
                    let authOptions: UNAuthorizationOptions = [.alert, .badge, .sound]
                   
                    UNUserNotificationCenter.current().requestAuthorization(options: authOptions) { didAllow, Error in
                        if Error == nil {
                            if didAllow {
                                // In case you want to register for the remote notifications
                            } else {
                                if let currentURL = self.webView.url?.absoluteString, currentURL.contains("setting.html") {
                                    print(currentURL, "contains uri")
                                    DispatchQueue.main.async {
                                        self.view.makeToast("알림 권한이 없습니다. 환경설정에서 허용으로 활성화 해주세요.")
                                        print("Permission denied")
                                    }
                                }
                            }
                        } else {
                            print(Error)
                        }
                    }
                    UIApplication.shared.registerForRemoteNotifications()
                }
            }
        }
    }

    override func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        super.webView(webView, didFinish: navigation)
        
        let pushToken: String? = webViewUtil.getData(key: "push_Token") ?? ""
        let push_YN: String? = webViewUtil.getData(key: "push_YN") ?? "Y"
        
        let script = "PushSet('IOS', '\(pushToken!)', '\(push_YN!)');"

        print(script)

        webView.evaluateJavaScript(script) { (result, error) in
            if let error = error {
                print("evaluateJavaScript error: \(error.localizedDescription)")
            }
        }
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping ((WKNavigationActionPolicy) -> Void)) {
        
        guard let url = navigationAction.request.url else { return }

        let decisionHandlerWrapper = DecisionHandlerWrapper(decisionHandler: decisionHandler, defaultValue: .allow)
        
        if url.scheme == "http" || url.scheme == "https" {
            if url.absoluteString.contains("roblox.com") {
                let safari = SFSafariViewController(url: url)
                present(safari, animated: true)
                decisionHandlerWrapper.respondHandler(.cancel)
                return
            }
        }
        decisionHandlerWrapper.respondHandler(.allow)
    }
    
    override func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        
        guard let url = navigationAction.request.url else { return nil }
        
        if url.absoluteString == "" || url.absoluteString.contains("about:blank") {
            return nil
        }

        print("newWindowURL : " + url.absoluteString)

        if url.scheme == "http" || url.scheme == "https" {
            var barTitle = ""

            // 후보 URL 리스트
            let ipinURLPatterns = [
                "ipin.ok-name.co.kr",
                "auth_ipin.html",
                "auth_ipin_result.html",
                "signup_ipin_auth.html",
                "signup_ipin_auth_result.html",
            ]
            let socialLoginURLPatterns = [
                "kauth.kakao.com",
                "nid.naver.com",
                "www.facebook.com",
                "appleid.apple.com"
            ]
            let phoneAuthURLPatterns = [
                "ipin.ok-name.co.kr",
                "auth_phone.html",
                "auth_phone_result.html",
                "signup_phone_auth.html",
                "signup_phone_auth_result.html",
            ]

            // 현재 웹 페이지의 URL이 후보 URL 중 하나에 속하는지 확인
            if phoneAuthURLPatterns.contains(where: { url.absoluteString.contains($0) }) {
                barTitle = "휴대폰 인증"
            }
            else if socialLoginURLPatterns.contains(where: { url.absoluteString.contains($0) }) {
                barTitle = "SNS 로그인"
            }
            else if ipinURLPatterns.contains(where: { url.absoluteString.contains($0) }) {
                barTitle = "공공아이핀 인증"
            }
            else {
                let safari = SFSafariViewController(url: url)
                present(safari, animated: true)
                return nil
            }
            
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let subWebView = WKWebView(frame: CGRectZero, configuration: configuration)

            let authWebViewController = storyBoard.instantiateViewController(identifier: "authWebViewController") { creator in
                return AuthWebViewController(webView: subWebView, coder: creator)
            }
                
            authWebViewController.navigationItem.title = barTitle
            
            DispatchQueue.main.async {
                // self.present(subViewController, animated:true, completion:nil)
                let backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: self, action: nil) // title 부분 수정
                    backBarButtonItem.tintColor = .black
                self.navigationItem.backBarButtonItem = backBarButtonItem
                self.navigationController?.pushViewController(authWebViewController, animated: true)
            }
            
            return subWebView
        }
            
        return super.webView(webView, createWebViewWith: configuration, for: navigationAction, windowFeatures: windowFeatures)
    }
}
