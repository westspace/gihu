//
//  BaseWebViewController.swift
//  ClimateAction
//
//  Copyright © CODExBridge. All rights reserved.
//

import UIKit
import SVProgressHUD
import WebKit
import SafariServices
import Toast_Swift

class BaseWebViewController: UIViewController, WKNavigationDelegate, WKDownloadDelegate, WKUIDelegate, UIScrollViewDelegate, WKScriptMessageHandler, SFSafariViewControllerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    let webViewUtil = WebViewUtil()
    
    public var loadedURL: URL!

    let group = DispatchGroup()
    
    @IBOutlet weak var closeButton: UIBarButtonItem!
    @IBOutlet weak var webViewContainer: UIView!
    
    lazy var webView = WKWebView()
    ///window.open()으로 열리는 새창
    var webViewStack = [WKWebView]()
    
    override func loadView() {
        super.loadView()
                
        self.webView = createWebView()
        self.webViewStack.append(webView)
    }
    
    func createWebView() -> WKWebView {
        var webView = WKWebView()
        let webViewConfiguration = WKWebViewConfiguration()
        let userContentController = webViewConfiguration.userContentController
        
        userContentController.add(self, name: "Mobile")   // JSON
        
        if #available(iOS 14.0, *) {
            webViewConfiguration.defaultWebpagePreferences.allowsContentJavaScript = true
        } else {
                // Fallback on earlier versions
            webViewConfiguration.preferences.javaScriptEnabled = true
        }
        webViewConfiguration.preferences.javaScriptCanOpenWindowsAutomatically = true

        //Need to reuse the same process pool to achieve cookie persistence
        let processPool = WKProcessPool()
        webViewConfiguration.processPool = processPool

        //group.notify(queue: DispatchQueue.main) {
            webView = self.settingWebViewUI(webViewConfiguration: webViewConfiguration)
        //}
        //group.wait()
        
        return webView
    }
    
    func settingWebViewUI(webViewConfiguration: WKWebViewConfiguration) -> WKWebView {
        let webView = WKWebView(frame: self.webViewContainer.bounds, configuration: webViewConfiguration)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.delegate = self
        webView.scrollView.bounces = true
        webView.scrollView.contentSize = self.webView.bounds.size
        
        webView.navigationDelegate = self
        webView.uiDelegate = self
        
        webView.allowsBackForwardNavigationGestures = true
        self.webViewContainer.addSubview(webView)

        return webView
    }
    
    // MARK: 뷰 라이프사이클
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //automaticallyAdjustsScrollViewInsets = false
        HTTPCookieStorage.shared.cookieAcceptPolicy = HTTPCookie.AcceptPolicy.always
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // 미리 지정된 URL로 로딩
    func loadWebView(url: URL) {
        DispatchQueue.main.async {
            var webrequest = URLRequest(url: url)
            let cookies = HTTPCookie.requestHeaderFields(with: HTTPCookieStorage.shared.cookies(for: webrequest.url!)!)
            if let value = cookies["Cookie"] { webrequest.addValue(value, forHTTPHeaderField: "Cookie") }
            
            self.webView.load(webrequest)
            self.loadedURL = url
        }
    }
    
    func getTitle() -> String {
        if (navigationItem.title != nil) {
            return navigationItem.title!
        }
        else if (title != nil) {
            return title!
        }
        else {
            return "기후행동1.5℃"
        }
    }
    
    // Disable Zoom for WebView
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        return nil
    }   
        
    // MARK: - 웹뷰 관련
    func parseMessageBodyToDict(messageBody: Any) -> [String: Any]? {
        if let jsonData = try? JSONSerialization.data(withJSONObject: messageBody, options: []),
           let parsedData = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
            return parsedData
        }
        return nil
    }
    
    // 웹 -> 네이티브 : 신규 코드
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        print(message.name)
        print(message.body)
        
    }
    
    func safariViewController(_ controller: SFSafariViewController, didCompleteInitialLoad didLoadSuccessfully: Bool) {
        //
    }
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if (isViewLoaded && (view.window != nil)) {
            //SVProgressHUD.show(withStatus: "로딩중...")
        }
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        SVProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        SVProgressHUD.dismiss()
        
        //webView.evaluateJavaScript("scrollTo(0, 0)", completionHandler: nil)
    }

    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        
        if challenge.previousFailureCount > 0 {
            completionHandler(.cancelAuthenticationChallenge, nil)
        } else if let serverTrust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: serverTrust))
        } else {
            print("unknown state. error: \(String(describing: challenge.error))")
        }
        
        SVProgressHUD.dismiss()
    }
    
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        
        print(suggestedFilename)
    }
    

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        
        var isFileDownload = false
        let url = navigationResponse.response.url
        let mimeType = navigationResponse.response.mimeType

        if mimeType?.contains("application/pdf") ?? false {
            let safariViewController = SFSafariViewController(url: url!)
            safariViewController.delegate = self
            self.present(safariViewController, animated: true, completion: nil)

            decisionHandler(.cancel)
            return
        }
        else if !navigationResponse.canShowMIMEType {
            decisionHandler(.download)
            return
        }

        decisionHandler(.allow)
    }
    
    
    // MARK: WKWebView Javascript CallBack
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // webView 생성
        let webView = settingWebViewUI(webViewConfiguration: configuration)

        webViewStack.append(webView)
        return webView
    }
    
    func webViewDidClose(_ webView: WKWebView) {
        for view in webView.subviews {
            view.removeFromSuperview()
        }
        webView.removeFromSuperview()
        self.webViewStack.removeLast()
    }
    
    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin, initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType, decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        // 항상 권한 유지
        decisionHandler(.grant)
    }
    
//    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping ((WKNavigationActionPolicy) -> Void)) {
//    }
    
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping () -> Void) {
        let completionHandlerWrapper = CompletionHandlerWrapper(completionHandler: completionHandler, defaultValue: Void())
        
        let alertController = UIAlertController(title: self.getTitle(), message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "확인", style: .default, handler: { (action) in
            completionHandlerWrapper.respondHandler(())
        }))
            
        self.present(alertController, animated: true, completion: nil)
    }
    
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (Bool) -> Void) {
        let completionHandlerWrapper = CompletionHandlerWrapper(completionHandler: completionHandler, defaultValue: false)
        
        let alertController = UIAlertController(title: self.getTitle(), message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "확인", style: .default, handler: { (action) in
            completionHandlerWrapper.respondHandler(true)
        }))
        alertController.addAction(UIAlertAction(title: "취소", style: .default, handler: { (action) in
            completionHandlerWrapper.respondHandler(false)
        }))
            
        self.present(alertController, animated: true, completion: nil)
    }
    
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo,
                 completionHandler: @escaping (String?) -> Void) {
        let completionHandlerWrapper = CompletionHandlerWrapper(completionHandler: completionHandler, defaultValue: "")

        let alertController = UIAlertController(title: self.getTitle(), message: prompt, preferredStyle: .alert)
        alertController.addTextField { (textField) in
            textField.text = defaultText
        }
        alertController.addAction(UIAlertAction(title: "확인", style: .default, handler: { (action) in
            if let text = alertController.textFields?.first?.text {
                completionHandlerWrapper.respondHandler(text)
            } else {
                completionHandlerWrapper.respondHandler(defaultText)
            }
        }))
        
        alertController.addAction(UIAlertAction(title: "취소", style: .default, handler: { (action) in
            completionHandler(nil)
        }))
            
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func handleClose(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    func openPhotoLib(){
        // 사용자에게 사진에 접근할 수 있는지 묻는다.
        let isOk = UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary)
        
        if isOk {
            // 이미지 피커 컨트롤러 --> 카메라, 갤러리 호출 기능
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            //이미지 정사각형으로만 선택 가능 여부
            //imagePicker.allowsEditing = true
            
            //갤러리 호출
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    /** 사진 촬영이나 선택을 취소한 경우 호출됨 */
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        // 취소시에 이 함수가 호출되지만 카메라나 갤러리가 닫히지는 않는다.
        // --> 강제로 화면을 닫는다.
        picker.dismiss(animated: true, completion: nil)
    }
    
    /** 사진 촬영이나 선택이 완료된 경우 호출됨 */
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        // 정보 딕셔너리
        print(info)
        
        //최종 사용할 이미지
        var useImage : UIImage!

        
        // 원본 이미지의 바이너리 얻기
        let originalImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        
        // 편집본의 바이너리 얻기
        let editedImage = info[UIImagePickerControllerEditedImage] as? UIImage
        
        // 편집본의 존재 여부에 따라서 표시할 이미지 선택
        if editedImage == nil {
            useImage = originalImage
        }else{
            useImage = editedImage
        }
        let jpegCompressionQuality: CGFloat = 0.05 // Set this to whatever suits your purpose
        
        if let base64String = UIImageJPEGRepresentation(useImage, jpegCompressionQuality)?.base64EncodedString() {
            // Upload base64String to your database
            webView.evaluateJavaScript("photo_callback('\(base64String)')")
        }
        
        //imageView.image = useImage
        
        //카메라나 갤러리 닫기
        picker.dismiss(animated: true, completion: nil)
    }
    
    
}

